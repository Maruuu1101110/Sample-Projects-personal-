import pygame as pg 
from pygame.locals import *
import random
import json
pg.init()

# main window and others
width = 1200
height = 700
window = pg.display.set_mode((width,height))
window_center = width // 2
clock = pg.time.Clock()
fps = 60
font = pg.font.SysFont("Lucida Console",25)
score = 0

# Colors and color management(transition)
white = pg.Color(255,255,255)
black = pg.Color(0,0,0)
gray = pg.Color(41,41,41)
yellow = pg.Color(255,255,0)
green = pg.Color(0,255,0)
transition_score = 1000
t_time = 0

# Rawr
dino_w, dino_h = 25,50
dino_x, dino_y = 50, height - (dino_h - 25)
dino = pg.Rect(dino_x, dino_y,dino_w,dino_h)

# Land
land_h = 2
land_y = height - 25
land = pg.Rect(0, land_y, width + 250, land_h)

# cactus
cactus_speed = 5
cac_w, cac_h = 25, 50
cac_frequency = 3
cactus = [pg.Rect(random.randint(width,width + 1000), land_y - 50, cac_w, cac_h) for _ in range(cac_frequency)]

# gravity stuff
velocity = 0
gravity_str = 0.5
jump_strength = -12
ground_y = land_y - 50

# highscore handling
def load_hs():
    with open("leaderboards.json","r") as loadfile:
        return json.load(loadfile)
def save_hs(score):
    with open("leaderboards.json","w") as savefile:
        return json.dump(score,savefile)
highscore = load_hs()

# reset data after game over
def rewrite():
    global dino, cactus, cactus_speed, cac_frequency, score, t_time
    dino.x, dino.y = dino_x, dino_y
    score = 0
    t_time = 0
    cactus_speed = 5
    cac_frequency = 3
    cactus.clear()
    for _ in range(cac_frequency):
        cactus.append(pg.Rect(random.randint(width, width + 1000), land_y - 50, cac_w, cac_h))

# Game Over
def game_over():
    pause = True
    while pause:
        window.fill(gray.lerp(white, t_time))
        window.blit(font.render("Game Over!",True,white.lerp(black, t_time)), (width // 2 - 75, height // 2 - 50))
        window.blit(font.render(f"Your Score: {int(score)}",True, white.lerp(black, t_time)), (width // 2 - 125, height // 2 - 10))
        window.blit(font.render("Press SPACE to try again",True,white.lerp(black, t_time)), (width // 2 - 160, height // 2 + 30))   
        for event in pg.event.get():
            if event.type == QUIT:
                pg.quit()
                exit
            if event.type == KEYDOWN and event.key == K_SPACE:
                pause = False
                rewrite()

        pg.display.flip()

# Main Menu  Screen
def menu():
    menu = True
    while menu:
        window.fill(gray)
        window.blit(font.render("DINO GAME", True, white), (width // 2 - 75, height // 2 - 50))
        window.blit(font.render("Press SPACE to Start",True, white), (width // 2 - 150, height // 2 + 30))
        for event in pg.event.get():
            if event.type == QUIT:
                pg.quit()
                exit
            if event.type == KEYDOWN and event.key == K_SPACE:
                menu = False
        pg.display.flip()

# main program
run = True
menu()
while run:
    clock.tick(fps)
    if score >= transition_score:
        t_time = min(t_time + 0.02, 1.0)

    window.fill(gray.lerp(white, t_time))   
    cactus_speed = 5 + (score // 300)
    score += 0.5
    
    # quit
    for event in pg.event.get():
        if event.type == QUIT:
            run = False
    
    # controls
    keys = pg.key.get_pressed()
    if keys[pg.K_SPACE] and dino.y >= ground_y:
        velocity = jump_strength             
        
    #gravity check
    velocity += gravity_str
    dino.y += velocity
    
    # ground collision
    if dino.y >= ground_y:
        dino.y = ground_y
        velocity = 0
    
    # move cactus..or player dunno ..also dispose cac for memory optimization
    for cac in cactus[:]:
        cac.x -= cactus_speed
        if cac.right < 0:
            cactus.remove(cac)
            cactus.append(pg.Rect(random.randint(width, width + 1000), land_y - 50, cac_w, cac_h))
    
    # dino collision w/ cactus
    for cac in cactus:
        if dino.colliderect(cac):
            game_over()
    
    # land draw
    pg.draw.rect(window,white.lerp(gray, t_time),land)

    # dino draw
    pg.draw.rect(window,white.lerp(gray, t_time),dino)

    # cactus draw
    for cac in cactus:
        pg.draw.rect(window, yellow.lerp(green, t_time), (cac[0],cac[1],cac_w,cac_h)) 
        
    # scoring system
    if score > highscore["highscore"]:
        highscore["highscore"] = score
    save_hs(highscore)
    score_text = font.render(f"Score: {int(score)}",True,white.lerp(black, t_time))
    hs_text = font.render(f"HI: {int(highscore['highscore'])}",True,white.lerp(black, t_time))
    window.blit(score_text,(50, 50))
    window.blit(hs_text,(50, 100))
                
    pg.display.flip()
    
pg.quit()