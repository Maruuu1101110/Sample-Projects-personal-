#Hangman
import json
import os
import random
import time

### OPEN SANG JSON FILE ###
### DAPAT SAME FOLDER SILA SANG MAIN FILE ###
def load_tasks():
    with open("hangmandata.json", "r") as file:
        return json.load(file)

interface = ['Start','Quit']
items = load_tasks()

def run():
    
    ### IMPORTANT DATA LOAD ETC² ###
    clue = random.choice(list(items.keys()))
    word = items[clue]
    user_guess = ['_'] * len(word)
    life = 5
    
    ### START PROGRAM ###
    while life > 0:
        print('\n','Welcome to Hangman!'.center(50),end='\r', flush=True)
        print(f'\nHere is Your Clue:\n\n\t"{clue}"\n')
        print(f'❤: {life}\n', end='\r', flush=True)   
        print(f'\nWord: {" ".join(user_guess)}', end='\r', flush=True)
        guess = input('\n\nYour Guess: ')[:1].lower()
        
        if guess in word:
            print('Correct!')
            for index, letter in enumerate(word):
                if letter == guess:
                    user_guess[index] = guess
            os.system('cls' if os.name == 'nt' else 'clear')
                
        elif guess not in word:
            print('Wrong Answer!'.center(50))
            life -= 1
            os.system('cls' if os.name == 'nt' else 'clear')
                
        if '_' not in user_guess:
            os.system('cls' if os.name == 'nt' else 'clear')
            print('\n',"You guessed the word!🥳".center(50))
            time.sleep(1)
            print(f'The word is: {word}')
            time.sleep(1)
            try_again = input("\nWould you like to try again? Y/N: ")
            if try_again == "y":
                os.system('cls' if os.name == 'nt' else 'clear')
                run()
            else:
                break
        
        if life == 0:
            print("Game Over! You ran out of lives🙁".center(50))
            try_again = input("\nWould you like to try again? Y/N: ").lower()
            if try_again == "y":
                os.system('cls' if os.name == 'nt' else 'clear')
                run()
            else:
                break
                
def main():
    ### INTERFACE SHT ###
    print('\n','Welcome to Hangman!'.center(50))
    for pos, i in enumerate(interface, start=1):
        print(f"{pos}. {i}\n")
    user_opt = input('Option: ')
    
    if user_opt == '1':
        os.system('cls' if os.name == 'nt' else 'clear')
        run()
    elif user_opt == '2':
        os.system('exit')
     
    else:
        print('Enter a Valid Option (1/2)...')
        time.sleep(2)
        os.system('cls' if os.name == 'nt' else 'clear')
        main()
    
if __name__=="__main__":
    main()
