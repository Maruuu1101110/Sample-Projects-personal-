#Hangman
import json
import os
import random
import time

### OPEN SANG JSON FILE ###
### DAPAT SAME FOLDER SILA SANG MAIN FILE ###
def load_tasks():
    with open("hangmandata.json", "r") as file:
        return json.load(file)
        
def save_data(items):
    with open("hangmandata.json", "w") as file:
        return json.dump(items, file, indent=4)

interface = ['Start','Quit']
items = load_tasks()
score = 0


def run():
    global score
    
    ### IMPORTANT DATA LOAD ETC² ###
    clue = random.choice(list(items.keys()))
    word = items[clue]
    user_guess = ['_'] * len(word)
    life = 5
    high_score = items["high_score"]
    
    ### START PROGRAM ###
    while life > 0:
        print('\n','Welcome to Hangman!'.center(50), end='\r', flush=True)
        print(f'\nHere is Your Clue:\n\n\t"{clue}"\n')
        print(f'\nScore: {score}\n', end='\r', flush=True)
        print(f'\n❤: {life}\n', end='\r', flush=True)
        print(f'\nWord: {" ".join(user_guess)}', end='\r', flush=True)
        guess = input('\n\nYour Guess: ')[:1].lower()
        
        if guess in word:
            print('Correct!')
            time.sleep(1)
            for index, letter in enumerate(word):
                if letter == guess:
                    user_guess[index] = guess
            os.system('cls' if os.name == 'nt' else 'clear')
                
        elif guess not in word:
            print('Wrong!😝'.center(50))
            time.sleep(1)
            life -= 1
            os.system('cls' if os.name == 'nt' else 'clear')
                
        if '_' not in user_guess:
            os.system('cls' if os.name == 'nt' else 'clear')
            print('\n',"You guessed the word!🥳".center(50))
            score += 1
            time.sleep(1)
            print(f'The word is: {word}')
            time.sleep(1)
            os.system('cls' if os.name == 'nt' else 'clear')
            run()
        
        if life == 0:
            os.system('cls' if os.name == 'nt' else 'clear')
            print('\n',"Game Over! You ran out of lives🙁".center(50))
            print(f'High Score: {high_score}\nYour total score is: {score}')
            time.sleep(1.5)
            break
            
    if score > high_score:
        items["high_score"] = score
        save_data(items)
        
    try_again = input("\nWould you like to try again? Y/N: ").lower()
    if try_again == 'y':
        os.system('cls' if os.name == 'nt' else 'clear')
        run()
    else:
        print(f"Thanks for playing!")
        time.sleep(1.5)
        os.system('exit')
    
                
def main():
    ### INTERFACE SHT ###
    print('\n','Welcome to Hangman!'.center(50))
    for pos, i in enumerate(interface, start=1):
        print(f"{pos}. {i}\n")
    user_opt = input('Option: ')
    
    if user_opt == '1':
        os.system('cls' if os.name == 'nt' else 'clear')
        run()
    
    elif user_opt == '2':
        print("Thanks for playing!")
        exit()
    else:
        print('Enter a Valid Option (1/2)...')
        time.sleep(2)
        os.system('cls' if os.name == 'nt' else 'clear')
        main()
    
if __name__=="__main__":
    main()
