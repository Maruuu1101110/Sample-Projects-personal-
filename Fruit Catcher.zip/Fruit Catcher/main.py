import pygame as pg
from pygame.locals import *
import random

# Window setup and objects initials
WIDTH, HEIGHT = 600,800
basket_size = 100
fruit_size, fruit_speed = 50, 3

# Colors
red = pg.Color(255,0,0)
green = pg.Color(0,255,0)
blue = pg.Color(0,0,255)
black = pg.Color(0,0,0)
white = pg.Color(242,242,242)
yellow = pg.Color(255,255,0)

# Object Initializer
class GameObject:
    def __init__(self, x, y, image=None):
        self.x = x
        self.y = y
        self.image = image
        self.rect = (pg.Rect(x, y, image.get_width(), 50) if image else None)

    # places objects on screen
    def draw(self, window):
        if self.image:
            window.blit(self.image, (self.x, self.y))
        elif self.rect:
            pg.draw.rect(window, red, self.rect)

    # updates ofcourse
    def update_rect(self):
        if self.rect:
            self.rect.topleft = (self.x, self.y)

# Objects Movement Handling
class Movable(GameObject):
    def move(self, dx=0, dy=0):
        self.x += dx
        self.y += dy
        self.update_rect()

# Basket Object
class Basket(Movable):
    def __init__(self, x, y, speed, image):
        super().__init__(x, y, image)
        self.speed = speed

    # key press for basket movement
    def handle_input(self):
        keys = pg.key.get_pressed()
        if keys[K_RIGHT] and self.x < WIDTH - basket_size:
            self.move(dx=self.speed)
        if keys[K_LEFT] and self.x > 0:
            self.move(dx=-self.speed)

# Falling Fruits Object
class Fruit(Movable):
    def __init__(self, x, y):
        super().__init__(x, y)
        self.image = pg.transform.scale(pg.image.load("Fruit Catcher/apple.png"),(fruit_size, fruit_size))
        self.rect = self.image.get_rect(topleft =(100,200))

    # upadte fruit falling / enable fall
    def update(self):
        self.move(dy=fruit_speed)

    # resets the falling fruits position
    def reset(self):
        self.x = random.randint(0, WIDTH - fruit_size)
        self.y = random.randint(-700, -50)
        self.update_rect()

# Main Class, handles how the game runs
class MainGame:
    def __init__(self):
        pg.init()
        self.window = pg.display.set_mode((WIDTH, HEIGHT))
        pg.display.set_caption("Fruit Catcher")
        self.clock = pg.time.Clock()
        self.fps = 60
        self.score = 0
        self.lives = 3
        self.font = pg.font.Font("Fruit Catcher/Supply Center.ttf", 20)
        self.title_font = pg.font.Font("Fruit Catcher/Supply Center.ttf", 40)
        self.timer = 0

        self.basket = Basket(WIDTH // 2 - basket_size // 2, HEIGHT - basket_size - 10, 7, pg.transform.scale(pg.image.load("Fruit Catcher/fruit_basket.png"), (basket_size, basket_size)))
        self.background = pg.transform.scale(pg.image.load("Fruit Catcher/background.jpg"), (WIDTH, HEIGHT))
        self.fruits = [Fruit(random.randint(0, WIDTH - fruit_size), random.randint(-700, -50)) for _ in range(2)]

    # run...
    def run(self):
        self.show_menu()
        run = True
        while run:
            self.timer += 0.015
            self.update_game()
            self.handle_events()
            self.draw_game()
            pg.display.flip()
            self.clock.tick(self.fps)
        pg.quit()

    # Showing intro / game menu
    def show_menu(self):
        menu = True
        while menu:
            self.window.blit(self.background, (0, 0))
            title = self.title_font.render("Fruit Catcher", 1, white)
            start_prmpt = self.font.render("Press SPACE to START", 1, white)
            self.window.blit(title, title.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 50)))
            self.window.blit(start_prmpt, start_prmpt.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
            for event in pg.event.get():
                if event.type == QUIT:
                    pg.quit()
                    exit()
                if event.type == KEYDOWN and event.key == K_SPACE:
                    menu = False
            pg.display.flip()
            self.clock.tick(self.fps)

    # handles game updates
    def update_game(self):
        for event in pg.event.get():
            if event.type == QUIT:
                pg.quit()
                exit()
        self.basket.handle_input()
        for fruit in self.fruits:
            fruit.update()
            if fruit.rect.colliderect(self.basket.rect):
                self.score += 5
                fruit.reset()
    
    # reset game data
    def rewrite(self):
        global fruit_speed
        self.lives = 3
        self.score = 0
        fruit_speed = 3
        self.fruits.clear()
        self.fruits = [Fruit(random.randint(0, WIDTH - fruit_size), random.randint(-700, -50)) for _ in range(2)]
        self.timer = 0

    # game over screen
    def game_over(self):
        pg.event.clear()
        game_over = True
        while game_over:
            game_over_txt = self.title_font.render("Game Over!", 1, red)
            final_score = self.font.render(f"Score: {self.score}", 1, green)
            restart_txt = self.font.render("Press SPACE to RESTART game", 1, white)
            self.window.blit(game_over_txt, game_over_txt.get_rect(center=(WIDTH // 2, HEIGHT // 3)))
            self.window.blit(final_score, final_score.get_rect(center=(WIDTH // 2, HEIGHT // 2.5)))
            self.window.blit(restart_txt, restart_txt.get_rect(center=(WIDTH // 2, HEIGHT // 2)))
            for event in pg.event.get():
                if event.type == QUIT:
                    pg.quit()
                    exit()
                if event.type == KEYDOWN and event.key == K_SPACE:
                    self.rewrite()
                    game_over = False
            pg.display.flip()
            self.clock.tick(self.fps)

    # ...dunno if this is important...
    def handle_events(self):
        global fruit_speed
        for event in pg.event.get():
            if event.type == QUIT:
                pg.quit()
                exit()
        for fruit in self.fruits:
            if fruit.y >= HEIGHT:
                self.lives -= 1
                fruit.reset()
        
        if self.timer >= 20:
            fruit_speed += 1
            self.timer = 0
        if self.lives == 0:
            self.game_over()

    # Draw all game objects and etcc
    def draw_game(self):
        self.window.blit(self.background, (0,0))
        self.basket.draw(self.window)
        for fruit in self.fruits:
            fruit.draw(self.window)
        score_txt = self.font.render(f"Score: {self.score}", 1, white)
        lives_txt = self.font.render(f"Lives: {self.lives}", 1, white)
        speed_level_txt = self.font.render(f"Level: {fruit_speed - 2}",1 ,white)
        self.window.blit(score_txt, (20,20))
        self.window.blit(lives_txt, (20,60))
        self.window.blit(speed_level_txt, (WIDTH - 150, 20))

        # Debug
        #self.window.blit(self.font.render(f"Fruit Speed: {fruit_speed - 2} {int(self.timer)}",1,white), (20, 100))

if __name__=="__main__":
    MainGame().run()